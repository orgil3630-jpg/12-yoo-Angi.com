-- ===== Supabase SQL: Supabase → SQL Editor дээр нэг удаа ажиллуулна =====

create table if not exists class_members_allowed (email text primary key);
create table if not exists admins (email text primary key);

create table if not exists registrations (
  id uuid primary key default gen_random_uuid(),
  event_slug text not null,
  name text not null,
  email text not null,
  phone text,
  attending text not null check (attending in ('ATTENDING','MAYBE','NOT_ATTENDING')),
  guests int not null default 0 check (guests between 0 and 5),
  note text,
  created_at timestamptz not null default now(),
  unique (event_slug, email)
);

alter table class_members_allowed enable row level security;
alter table admins enable row level security;
alter table registrations enable row level security;

-- Хэрэглэгч зөвхөн өөрийн мөрийг уншина
create policy "own member row" on class_members_allowed
  for select to authenticated using (email = auth.jwt() ->> 'email');
create policy "own admin row" on admins
  for select to authenticated using (email = auth.jwt() ->> 'email');

-- Бүртгэл: өөрийнхөө мөрийг унших, оруулах, засах
create policy "reg read own" on registrations
  for select to authenticated using (email = auth.jwt() ->> 'email');
create policy "reg read admin" on registrations
  for select to authenticated
  using (exists (select 1 from admins a where a.email = auth.jwt() ->> 'email'));
create policy "reg insert own" on registrations
  for insert to authenticated
  with check (email = auth.jwt() ->> 'email'
    and exists (select 1 from class_members_allowed m where m.email = registrations.email));
create policy "reg update own" on registrations
  for update to authenticated
  using (email = auth.jwt() ->> 'email')
  with check (email = auth.jwt() ->> 'email');

-- ===== Ангийнхны Gmail хаягуудыг энд нэмнэ (жишээ) =====
insert into class_members_allowed (email) values
  ('ner1@gmail.com'),
  ('ner2@gmail.com')
on conflict do nothing;

-- Админ: admins-д нэмэхдээ class_members_allowed-д бас байх ёстой
insert into class_members_allowed (email) values ('admin@gmail.com') on conflict do nothing;
insert into admins (email) values ('admin@gmail.com') on conflict do nothing;
