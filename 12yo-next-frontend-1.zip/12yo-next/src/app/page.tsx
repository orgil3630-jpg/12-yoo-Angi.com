"use client";

import { useState, useEffect } from "react";
import { SITE, STUDENTS, GALLERY, VIDEOS, TIMELINE, TEACHER, REUNION } from "@/lib/config";
import Image from "next/image";

export default function HomePage() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("Бүгд");
  const [selectedStudent, setSelectedStudent] = useState<number | null>(null);
  const [lightbox, setLightbox] = useState<number | null>(null);

  const filteredStudents = STUDENTS.filter(
    (s) =>
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.nickname.toLowerCase().includes(search.toLowerCase())
  );

  const categories = ["Бүгд", ...Array.from(new Set(GALLERY.map((g) => g.category)))];
  const filteredGallery =
    filter === "Бүгд" ? GALLERY : GALLERY.filter((g) => g.category === filter);

  return (
    <div className="min-h-screen bg-[#F7F3EA] text-[#242424] font-sans">
      {/* NAV */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#18283A]/95 backdrop-blur text-white">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <a href="#top" className="text-xl font-bold tracking-wide">
            12<span className="text-[#C9A96E]">Ё</span>
          </a>
          <div className="hidden md:flex gap-6 text-sm">
            <a href="#about" className="hover:text-[#C9A96E]">Бидний тухай</a>
            <a href="#students" className="hover:text-[#C9A96E]">Ангийнхан</a>
            <a href="#gallery" className="hover:text-[#C9A96E]">Галерей</a>
            <a href="#videos" className="hover:text-[#C9A96E]">Видео</a>
            <a href="#reunion" className="hover:text-[#C9A96E]">Уулзалт</a>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <header id="top" className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-[#18283A] via-[#263C52] to-[#18283A] text-white pt-16">
        <div className="absolute inset-0 opacity-20 bg-[url('/images/misc-01.jpg')] bg-cover bg-center" />
        <div className="relative z-10 text-center px-4 max-w-3xl mx-auto">
          <p className="text-[#C9A96E] text-sm tracking-widest uppercase mb-4">{SITE.kicker}</p>
          <h1 className="text-4xl md:text-6xl font-serif font-bold mb-4">{SITE.title}</h1>
          <div className="w-24 h-0.5 bg-[#C9A96E] mx-auto mb-6" />
          <p className="text-xl md:text-2xl text-[#E0C99A] mb-4">{SITE.subtitle}</p>
          <p className="text-base md:text-lg opacity-90 leading-relaxed mb-10">{SITE.heroText}</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="#students" className="px-8 py-3 bg-[#C9A96E] text-[#18283A] font-medium rounded hover:bg-[#E0C99A] transition">
              Ангийнхантай танилцах
            </a>
            <a href="#gallery" className="px-8 py-3 border border-white/40 rounded hover:bg-white/10 transition">
              Дурсамжаа үзэх
            </a>
            <a href="#reunion" className="px-8 py-3 border border-white/40 rounded hover:bg-white/10 transition">
              Уулзалтад бүртгүүлэх
            </a>
          </div>
        </div>
      </header>

      {/* ABOUT */}
      <section id="about" className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-[#C9A96E] text-sm tracking-widest uppercase mb-2">Бидний тухай</p>
          <h2 className="text-3xl md:text-4xl font-serif mb-8">{SITE.aboutTitle}</h2>
          {SITE.aboutParagraphs.map((p, i) => (
            <p key={i} className="text-lg leading-relaxed mb-4 opacity-90">{p}</p>
          ))}
          <div className="grid grid-cols-3 gap-6 mt-12">
            {SITE.aboutStats.map((s) => (
              <div key={s.label} className="bg-white rounded-lg p-6 shadow-sm">
                <div className="text-3xl font-bold text-[#18283A]">{s.value}</div>
                <div className="text-sm text-gray-500 mt-1">{s.label}</div>
              </div>
            ))}
          </div>
          <blockquote className="mt-12 text-2xl font-serif italic text-[#18283A]">
            “{SITE.aboutQuote.text}”
          </blockquote>
        </div>
      </section>

      {/* STUDENTS */}
      <section id="students" className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <p className="text-[#C9A96E] text-sm tracking-widest uppercase text-center mb-2">34 сурагч</p>
          <h2 className="text-3xl md:text-4xl font-serif text-center mb-4">Ангийнхан</h2>
          <p className="text-center text-gray-600 mb-8">Хүн бүрийг зураг дээр нь дарж дэлгэрэнгүй танилцаарай.</p>
          <div className="max-w-md mx-auto mb-10">
            <input
              type="search"
              placeholder="Нэр, хоч хайх..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C9A96E]"
            />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {filteredStudents.map((s) => (
              <button
                key={s.id}
                onClick={() => setSelectedStudent(s.id)}
                className="group text-left bg-[#F7F3EA] rounded-lg overflow-hidden hover:shadow-lg transition"
              >
                <div className="aspect-[3/4] relative bg-gray-200">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={s.photo}
                    alt={s.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = "/images/misc-01.jpg";
                    }}
                  />
                </div>
                <div className="p-3">
                  <div className="font-medium text-sm truncate">{s.name}</div>
                  {s.nickname && <div className="text-xs text-gray-500">{s.nickname}</div>}
                </div>
              </button>
            ))}
          </div>
          <p className="text-center text-sm text-gray-500 mt-6">{filteredStudents.length} сурагч</p>
        </div>
      </section>

      {/* GALLERY */}
      <section id="gallery" className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <p className="text-[#C9A96E] text-sm tracking-widest uppercase text-center mb-2">Зургийн цомог</p>
          <h2 className="text-3xl md:text-4xl font-serif text-center mb-4">Хуучин дурсамжууд</h2>
          <p className="text-center text-gray-600 mb-8">Ангилалаар шүүж, зураг дээр дарж томруулна уу.</p>
          <div className="flex flex-wrap justify-center gap-2 mb-10">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setFilter(c)}
                className={`px-4 py-1.5 rounded-full text-sm transition ${
                  filter === c ? "bg-[#18283A] text-white" : "bg-white border border-gray-200 hover:border-[#C9A96E]"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
          <div className="columns-2 md:columns-3 lg:columns-4 gap-4 space-y-4">
            {filteredGallery.map((g, i) => (
              <button
                key={g.file}
                onClick={() => setLightbox(i)}
                className="break-inside-avoid w-full rounded-lg overflow-hidden hover:opacity-90 transition"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={g.file} alt={g.title} className="w-full h-auto object-cover" />
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* VIDEOS */}
      <section id="videos" className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <p className="text-[#C9A96E] text-sm tracking-widest uppercase text-center mb-2">Видео</p>
          <h2 className="text-3xl md:text-4xl font-serif text-center mb-8">Ангийн дурсамж</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {VIDEOS.map((v) => (
              <div key={v.file} className="bg-[#F7F3EA] rounded-lg overflow-hidden">
                <div className="aspect-video bg-black">
                  <video
                    src={v.file}
                    poster={v.poster || undefined}
                    controls
                    className="w-full h-full object-contain"
                    playsInline
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-medium">{v.title}</h3>
                  {v.desc && <p className="text-sm text-gray-600 mt-1">{v.desc}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TIMELINE */}
      <section id="timeline" className="py-20 px-4">
        <div className="max-w-3xl mx-auto">
          <p className="text-[#C9A96E] text-sm tracking-widest uppercase text-center mb-2">Цаг хугацаа</p>
          <h2 className="text-3xl md:text-4xl font-serif text-center mb-12">Бидний замнал</h2>
          <div className="space-y-8">
            {TIMELINE.map((t) => (
              <div key={t.year} className="flex gap-6">
                <div className="text-[#C9A96E] font-bold text-xl w-20 shrink-0">{t.year}</div>
                <div className="border-l-2 border-[#C9A96E]/40 pl-6 pb-2">
                  <p className="text-lg">{t.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TEACHER */}
      <section className="py-16 px-4 bg-[#18283A] text-white text-center">
        <div className="max-w-2xl mx-auto">
          <div className="w-32 h-32 mx-auto rounded-full overflow-hidden mb-6 border-4 border-[#C9A96E]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={TEACHER.photo} alt="Багш" className="w-full h-full object-cover" />
          </div>
          <p className="text-xl italic font-serif">“{TEACHER.quote}”</p>
        </div>
      </section>

      {/* REUNION / REGISTRATION */}
      <section id="reunion" className="py-20 px-4 bg-gradient-to-br from-[#18283A] to-[#263C52] text-white">
        <div className="max-w-xl mx-auto text-center">
          <p className="text-[#C9A96E] text-sm tracking-widest uppercase mb-2">Уулзалт</p>
          <h2 className="text-3xl md:text-4xl font-serif mb-4">Дахин уулзах цаг</h2>
          <p className="opacity-90 mb-2">{REUNION.label}</p>
          <p className="opacity-80 mb-8">
            {SITE.reunionLocation} · {SITE.reunionTime} · {SITE.dressCode}
          </p>
          <div className="bg-white/10 backdrop-blur rounded-xl p-6 text-left">
            <p className="text-sm opacity-80 mb-4">
              Бүртгэл хийхийн тулд Gmail-ээр нэвтэрнэ үү. Зөвхөн ангийн жагсаалтад байгаа хаяг бүртгүүлэх боломжтой.
            </p>
            <p className="text-xs opacity-60">
              (Supabase Auth + Gmail API холболт хийгдсэнээр бүртгэлийн форм энд ажиллана. Одоогоор frontend бэлэн.)
            </p>
            <button className="mt-6 w-full py-3 bg-[#C9A96E] text-[#18283A] font-medium rounded hover:bg-[#E0C99A] transition">
              Gmail-ээр нэвтэрч бүртгүүлэх
            </button>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-10 px-4 bg-[#0b0a1a] text-white/70 text-center text-sm">
        <div className="text-2xl font-bold text-white mb-2">
          {SITE.footerLogo}
        </div>
        <p>{SITE.footerTagline}</p>
        <p className="mt-4 opacity-50">© {SITE.graduationYear} · 12ё анги</p>
      </footer>

      {/* Student modal */}
      {selectedStudent !== null && (
        <div
          className="fixed inset-0 z-[100] bg-black/70 flex items-center justify-center p-4"
          onClick={() => setSelectedStudent(null)}
        >
          <div
            className="bg-white rounded-xl max-w-sm w-full overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {(() => {
              const s = STUDENTS.find((x) => x.id === selectedStudent)!;
              return (
                <>
                  <div className="aspect-[3/4] relative">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={s.photo} alt={s.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="p-5">
                    <h3 className="text-xl font-medium">{s.name}</h3>
                    {s.nickname && <p className="text-gray-500">{s.nickname}</p>}
                    {s.line && <p className="mt-2 text-sm">{s.line}</p>}
                    <button
                      onClick={() => setSelectedStudent(null)}
                      className="mt-4 w-full py-2 border rounded hover:bg-gray-50"
                    >
                      Хаах
                    </button>
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      )}

      {/* Lightbox */}
      {lightbox !== null && (
        <div
          className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <button
            className="absolute top-4 right-4 text-white text-3xl"
            onClick={() => setLightbox(null)}
          >
            ×
          </button>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={filteredGallery[lightbox].file}
            alt={filteredGallery[lightbox].title}
            className="max-h-[90vh] max-w-full object-contain"
            onClick={(e) => e.stopPropagation()}
          />
          <p className="absolute bottom-6 left-0 right-0 text-center text-white/80">
            {filteredGallery[lightbox].title}
          </p>
        </div>
      )}
    </div>
  );
}
