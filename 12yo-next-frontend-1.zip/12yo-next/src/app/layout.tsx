import type { Metadata } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin", "cyrillic"], variable: "--font-sans" });
const playfair = Playfair_Display({ subsets: ["latin", "cyrillic"], variable: "--font-serif" });

export const metadata: Metadata = {
  title: "12Ё АНГИ | 12-р хөгжих цогцолбор сургууль",
  description: "12-р хөгжих цогцолбор сургуулийн 2021–2024 оны ангийн дурсамжийн digital yearbook",
  themeColor: "#0b0a1a",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="mn">
      <body className={`${inter.variable} ${playfair.variable} antialiased`}>
        {children}
      </body>
    </html>
  );
}
