// 12Ё анги — Сайтын тохиргоо
export const SUPABASE = {
  url: process.env.NEXT_PUBLIC_SUPABASE_URL || "https://YOUR-PROJECT.supabase.co",
  anonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "YOUR-ANON-KEY",
};

export const SCHOOL = {
  name: "Хөгжил цогцолбор сургууль",
  lat: null as number | null,
  lng: null as number | null,
};

export const REUNION = {
  eventSlug: "reunion-2034-07",
  label: "2034 оны 7 сар",
};

export const SITE = {
  title: "12Ё АНГИ",
  subtitle: "2021 — 2024. МЯНГАН ДУРСАМЖ.",
  kicker: "12-р хөгжих цогцолбор сургууль · 12ё анги · 2021 — 2024",
  heroText: "12ё ангид 2021 онд анх нэгдэж, 2024 онд хамтдаа төгссөн бид өнөөдөр өөр өөрийн замаар алхаж явна. Гэхдээ биднийг холбосон дурсамж үргэлж хамт.",
  heroImage: "",
  graduationYear: 2024,
  reunionDate: "2034-07-01",
  reunionTime: "18:00",
  reunionLocation: "Улаанбаатар",
  mapQuery: "Улаанбаатар, Монгол",
  dressCode: "Smart casual",
  aboutTitle: "Нэг ангийн түүх",
  aboutParagraphs: [
    "Бид 2021 онд 12-р хөгжих цогцолбор сургуулийн 12ё ангид анх нэгдсэн. Энд нөхөрлөл, хамтын ажил, анхны инээд бүгд хамт төрсөн.",
    "2024 онд хамтдаа төгссөн ч нэг ангийнхан гэдгээ мартаагүй. Энэ вэбсайт бол тэр дурсамжийг хамтдаа хадгалах зай юм.",
  ],
  aboutStats: [
    { value: "34", label: "Сурагч" },
    { value: "3", label: "Жил" },
    { value: "4", label: "Видео" },
  ],
  aboutQuote: { text: "Нэг анги. Мянган дурсамж.", by: "Нэг анги" },
  footerLogo: "12Ё",
  footerTagline: "Нэг анги. Хамтдаа дурсамж.",
};

export type Student = {
  id: number;
  name: string;
  nickname: string;
  line: string;
  photo: string;
};

export const STUDENTS: Student[] = [
  { id: 1, name: "Ө. Элбэгсайхан", nickname: "", line: "", photo: "/images/student-01.jpg" },
  { id: 2, name: "Г. Ганчимэг", nickname: "", line: "", photo: "/images/student-02.jpg" },
  { id: 3, name: "Г. Ганцэцэг", nickname: "", line: "", photo: "/images/student-03.jpg" },
  { id: 4, name: "Э. Жавхлан", nickname: "", line: "", photo: "/images/student-04.jpg" },
  { id: 5, name: "Б. Маралмаа", nickname: "", line: "", photo: "/images/student-05.jpg" },
  { id: 6, name: "Г. Мингён", nickname: "", line: "", photo: "/images/student-06.jpg" },
  { id: 7, name: "Э. Мөнх-Уянга", nickname: "", line: "", photo: "/images/student-07.jpg" },
  { id: 8, name: "Н. Хүслэн", nickname: "", line: "", photo: "/images/student-08.jpg" },
  { id: 9, name: "О. Номинзаяа", nickname: "", line: "", photo: "/images/student-09.jpg" },
  { id: 10, name: "П. Нямзул", nickname: "", line: "", photo: "/images/student-10.jpg" },
  { id: 11, name: "Б. Мөнх-Оргил", nickname: "", line: "", photo: "/images/student-11.jpg" },
  { id: 12, name: "Э. Отгонцэцэг", nickname: "", line: "", photo: "/images/student-12.jpg" },
  { id: 13, name: "А. Одонгоо", nickname: "", line: "", photo: "/images/student-13.jpg" },
  { id: 14, name: "А. Сайнбилэг", nickname: "", line: "", photo: "/images/student-14.jpg" },
  { id: 15, name: "Г. Шэнэн", nickname: "", line: "", photo: "/images/student-15.jpg" },
  { id: 16, name: "Т. Солонго", nickname: "", line: "", photo: "/images/student-16.jpg" },
  { id: 17, name: "Т. Төгөлдөр", nickname: "", line: "", photo: "/images/student-17.jpg" },
  { id: 18, name: "А. Тулга", nickname: "", line: "", photo: "/images/student-18.jpg" },
  { id: 19, name: "Л. Мөнхтушиг", nickname: "", line: "", photo: "/images/student-19.jpg" },
  { id: 20, name: "Н. Галбадрах", nickname: "", line: "", photo: "/images/student-20.jpg" },
  { id: 21, name: "О. Энххүслэн", nickname: "", line: "", photo: "/images/student-21.jpg" },
  { id: 22, name: "Х. Дөлгөөн", nickname: "", line: "", photo: "/images/student-22.jpg" },
  { id: 23, name: "Ц. Чингүүн", nickname: "", line: "", photo: "/images/student-23.jpg" },
  { id: 24, name: "Б. Бэлгүүдэй", nickname: "", line: "", photo: "/images/student-24.jpg" },
  { id: 25, name: "Т. Баяржавхлан", nickname: "", line: "", photo: "/images/student-25.jpg" },
  { id: 26, name: "С. Батдорж", nickname: "", line: "", photo: "/images/student-26.jpg" },
  { id: 27, name: "Ц. Бархасболд", nickname: "", line: "", photo: "/images/student-27.jpg" },
  { id: 28, name: "Б. Төгөлдөр", nickname: "", line: "", photo: "/images/student-28.jpg" },
  { id: 29, name: "Б. Хүслэн", nickname: "", line: "", photo: "/images/student-29.jpg" },
  { id: 30, name: "Г. Анхбаяр", nickname: "", line: "", photo: "/images/student-30.jpg" },
  { id: 31, name: "Д. Амарсанаа", nickname: "", line: "", photo: "/images/student-31.jpg" },
  { id: 32, name: "П. Гүнжидмаа", nickname: "", line: "", photo: "/images/student-32.jpg" },
  { id: 33, name: "Ө. Алтангэрэл", nickname: "", line: "", photo: "/images/student-33.jpg" },
  { id: 34, name: "С. Оюунмаа", nickname: "", line: "", photo: "/images/student-34.jpg" },
];

export type VideoItem = {
  file: string;
  poster: string;
  title: string;
  desc: string;
  category: string;
};

export const VIDEOS: VideoItem[] = [
  { file: "/videos/video-01.mp4", poster: "/images/misc-01.jpg", title: "12ё ангийн дурсамж", desc: "Ангийнхаа хамт үлдээсэн дурсамжит агшин", category: "Сургуулийн үе" },
  { file: "/videos/video-02.mp4", poster: "", title: "Ангийн дурсамж 02", desc: "", category: "Бусад" },
  { file: "/videos/video-03.mp4", poster: "", title: "Ангийн дурсамж 03", desc: "", category: "Бусад" },
  { file: "/videos/video-04.mp4", poster: "", title: "Ангийн дурсамж 04", desc: "", category: "Бусад" },
];

export type GalleryItem = {
  file: string;
  title: string;
  category: string;
  year: number | null;
};

export const GALLERY: GalleryItem[] = [
  { file: "/images/gallery/g1.jpg", title: "Ангийн мөч", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g2.jpg", title: "Найзууд", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g3.jpg", title: "Сургууль", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g4.jpg", title: "Аялал", category: "Аялал", year: null },
  { file: "/images/gallery/g5.jpg", title: "Хамт олон", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g6.jpg", title: "Инээд", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g7.jpg", title: "Дурсамж", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g8.jpg", title: "Уулзалт", category: "Аялал", year: null },
  { file: "/images/gallery/g9.jpg", title: "Баярын мөч", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g10.jpg", title: "Хичээл", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g11.jpg", title: "Гадаа", category: "Аялал", year: null },
  { file: "/images/gallery/g12.jpg", title: "Найзуудтай", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g13.jpg", title: "Төгсөлт", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g14.jpg", title: "Байгаль", category: "Аялал", year: null },
  { file: "/images/gallery/g15.jpg", title: "Ангийнхан", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g16.jpg", title: "Мөчүүд", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g17.jpg", title: "Хамтдаа", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g18.jpg", title: "Инээд хөөр", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g19.jpg", title: "Аялал 2", category: "Аялал", year: null },
  { file: "/images/gallery/g20.jpg", title: "Сургуулийн хашаа", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g21.jpg", title: "Найзууд", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g22.jpg", title: "Дурсамжит өдөр", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g23.jpg", title: "Ууланд", category: "Аялал", year: null },
  { file: "/images/gallery/g24.jpg", title: "Хотын дунд", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g25.jpg", title: "Найзуудтай зураг", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g26.jpg", title: "Сургуулийн мөч", category: "Ангийн амьдрал", year: null },
  { file: "/images/gallery/g27.jpg", title: "Ууланд найзуудтай", category: "Аялал", year: null },
  { file: "/images/gallery/g28.jpg", title: "Хамт олон байгальд", category: "Аялал", year: null },
  { file: "/images/gallery/g29.jpg", title: "Хадан дээр", category: "Аялал", year: null },
  { file: "/images/gallery/g30.jpg", title: "Хадан дээр найзууд", category: "Аялал", year: null },
  { file: "/images/gallery/g31.jpg", title: "Сургуулийн хичээлийн мөч", category: "Ангийн амьдрал", year: null },
];

export const TIMELINE = [
  { year: "2021", text: "Анх нэг ангид орсон. Бүгд бие биенээ мэддэггүй байсан." },
  { year: "2022", text: "Хамтдаа хичээлийн жилүүд, шалгалт, нууц инээд." },
  { year: "2023", text: "Хамтын ажил, арга хэмжээ, найрсаг мөчүүд." },
  { year: "2024", text: "Төгсөлт. Нэг анги хамтдаа төгссөн." },
  { year: "Дараа", text: "Уулзалт. Нэг анги дахин нэгдэнэ." },
];

export const TEACHER = {
  name: "Багш",
  photo: "/images/teacher.jpg",
  quote: "Бидний анхны алхмыг хамт алхаж, зам заасан багшдаа — баярлалаа.",
};
