# 12Ё анги — Next.js Frontend (Эцсийн хувилбар)

Өмнөх статик веб (site_v2)-ийн **бүх дизайн, зураг, галерей, видео, контент**-ыг хадгалж, Next.js + App Router + Tailwind дээр шилжүүлсэн frontend.

## Юу багтсан бэ

- Hero, About, Ангийнхан (34 сурагч), Gallery (31 зураг), Videos, Timeline, Teacher, Reunion бүртгэлийн хэсэг
- Responsive (mobile / tablet / desktop)
- Зураг, видео `public/images`, `public/videos` дотор
- Тохиргоо нэг газар: `src/lib/config.ts`
- Lightbox, student modal, search, category filter

## Байршуулах (Vercel)

1. Supabase төсөл үүсгээд `supabase.sql`-ийг ажиллуулна (extracted_site дотор байгаа).
2. Environment variables:
   ```
   NEXT_PUBLIC_SUPABASE_URL=...
   NEXT_PUBLIC_SUPABASE_ANON_KEY=...
   SUPABASE_SERVICE_ROLE_KEY=...   # зөвхөн server
   GMAIL_CLIENT_ID=...
   GMAIL_CLIENT_SECRET=...
   GMAIL_REFRESH_TOKEN=...
   ```
3. Vercel дээр deploy: GitHub-д push хийгээд Vercel import.
4. Domain холбоно.

## Дараагийн алхам (Backend)

- Supabase Auth (Google OAuth) + RLS
- Registration API route → email_logs
- Gmail API (server-side only) send + retry
- Admin хуудас (`/admin`) — registration list, email status, event update email

## Ажиллуулах

```bash
cd 12yo-next
npm install
npm run dev
```

## Анхаарах

- Видео файлууд том тул `public/videos/` руу гараар хуулсан эсэхийг шалгана.
- `config.ts`-д нэр, текст, галерейн гарчиг засна.
- Gmail password хадгалахгүй, зөвхөн refresh token server env-д.
